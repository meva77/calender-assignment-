-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 24, 2013 at 08:51 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `javatest_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `calendar`
--

CREATE TABLE IF NOT EXISTS `calendar` (
  `name` varchar(30) NOT NULL,
  `description` varchar(100) NOT NULL,
  `time` varchar(30) NOT NULL,
  `status` varchar(11) NOT NULL,
  `sceduler` varchar(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `calendar`
--

INSERT INTO `calendar` (`name`, `description`, `time`, `status`, `sceduler`, `id`) VALUES
('website', 'create website for the distributed systems calss', '8 pm monday', 'group', 'lambert', 10),
('paper', 'paper on thursday need to read', '12 pm', 'group', 'lambert', 12),
('swim', 'after the paper on thursday', '3 pm', 'group', 'lambert', 13),
('hair cut', 'go to town to get my hair treamed', '4 pm', 'private', 'lambert', 14);

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `name` varchar(30) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`name`, `id`) VALUES
('lambert', 1),
('louise', 2);
